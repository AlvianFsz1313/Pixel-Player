# Pixel Player

Video player Android dengan:
- Interpolasi frame motion-compensated -> gerakan 120 fps walau video 24/30 fps (butuh layar 120 Hz)
- Super Resolution: EASU + RCAS (algoritma AMD FSR 1.0) atau upscaler klasik Catmull-Rom
  (ini algoritma spasial adaptif-tepi, BUKAN neural network)
- Target upscale: "Layar" (default, tepat sebesar yang tampil), 4K, 1440p, atau OFF
- Kontrol Play / Pause / Stop / Seek, buka file video, tombol toggle Upscale, SR & 120 FPS
- Status bar menampilkan fps video, fps render SEBENARNYA, dan Hz layar

## Membaca status
`Video 30 fps | Render 118 fps | Layar 120 Hz`
- Render ~ Hz layar  -> pipeline sehat; kalau gerakan masih patah-patah, itu soal kualitas interpolasi.
- Render << Hz layar -> GPU kewalahan (turunkan Upscale / matikan SR).
- Layar 60 Hz padahal minta 120 -> OS/ROM membatasi refresh rate app ini (cek mode layar & power saving).

## Build
Push ke GitHub -> tab **Actions** -> workflow "Build Pixel Player APK" -> download APK dari **Artifacts**.
Push tag `v1.0` untuk otomatis membuat GitHub Release berisi APK.

Lokal: `gradle assembleDebug` (Gradle 8.9, JDK 17, Android SDK 34).
