# Pixel Player

Video player Android dengan:
- Interpolasi frame motion-compensated -> gerakan 120 fps walau video 24/30 fps (butuh layar 120 Hz)
- Upscale ke 1440p / 4K (Catmull-Rom + anti-ringing sharpen)
- Kontrol Play / Pause / Stop / Seek, buka file video, tombol toggle Upscale & 120 FPS

## Build
Push ke GitHub -> tab **Actions** -> workflow "Build Pixel Player APK" -> download APK dari **Artifacts**.
Push tag `v1.0` untuk otomatis membuat GitHub Release berisi APK.

Lokal: `gradle assembleDebug` (Gradle 8.9, JDK 17, Android SDK 34).
