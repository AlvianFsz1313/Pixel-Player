package com.pixelplayer

import android.content.Intent
import android.net.Uri
import android.opengl.GLSurfaceView
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Surface
import android.view.SurfaceHolder
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer

class MainActivity : AppCompatActivity() {

    private lateinit var glView: GLSurfaceView
    private lateinit var renderer: PlayerRenderer
    private lateinit var player: ExoPlayer
    private lateinit var controls: View
    private lateinit var status: TextView
    private lateinit var timeCur: TextView
    private lateinit var timeTotal: TextView
    private lateinit var seek: SeekBar
    private lateinit var btnUpscale: Button
    private lateinit var btnSr: Button
    private lateinit var btnFps: Button

    private val ui = Handler(Looper.getMainLooper())
    private var seeking = false
    private var upscaleMode = 0 // 0 = ikuti layar, 1 = 4K, 2 = 1440p, 3 = off
    private var maxHz = 120f
    private var lastRateVote = 0L
    private var currentName = ""

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            try {
                contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
            play(it)
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            updateUi()
            // Ulangi permintaan refresh rate tiap ~1 dtk (beberapa ROM me-reset-nya sendiri)
            val now = SystemClock.uptimeMillis()
            if (now - lastRateVote > 1000) {
                lastRateVote = now
                requestSurfaceRate(glView.holder)
            }
            ui.postDelayed(this, 250)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemBars()

        glView = findViewById(R.id.glView)
        controls = findViewById(R.id.controls)
        status = findViewById(R.id.status)
        timeCur = findViewById(R.id.timeCur)
        timeTotal = findViewById(R.id.timeTotal)
        seek = findViewById(R.id.seek)
        btnUpscale = findViewById(R.id.btnUpscale)
        btnSr = findViewById(R.id.btnSr)
        btnFps = findViewById(R.id.btnFps)

        // Player dibuat lebih dulu supaya callback surface selalu punya tujuan
        player = ExoPlayer.Builder(this).build()
        // Jangan biarkan ExoPlayer mengubah frame rate / mode layar mengikuti fps video (24/30)
        player.setVideoChangeFrameRateStrategy(C.VIDEO_CHANGE_FRAME_RATE_STRATEGY_OFF)
        player.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                renderer.setVideo(videoSize.width, videoSize.height, videoSize.pixelWidthHeightRatio)
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                updateUi()
            }

            override fun onPlayerError(error: PlaybackException) {
                Toast.makeText(this@MainActivity, "Error: ${error.errorCodeName}", Toast.LENGTH_LONG).show()
            }
        })

        renderer = PlayerRenderer { surface ->
            runOnUiThread { player.setVideoSurface(surface) }
        }
        glView.setEGLContextClientVersion(3)
        glView.setRenderer(renderer)
        glView.renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
        glView.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) = requestSurfaceRate(holder)
            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) =
                requestSurfaceRate(holder)

            override fun surfaceDestroyed(holder: SurfaceHolder) {}
        })
        glView.setOnClickListener {
            controls.visibility = if (controls.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }

        findViewById<Button>(R.id.btnOpen).setOnClickListener { picker.launch(arrayOf("video/*")) }
        findViewById<Button>(R.id.btnPlay).setOnClickListener {
            if (player.playbackState == Player.STATE_ENDED) player.seekTo(0)
            player.play()
        }
        findViewById<Button>(R.id.btnPause).setOnClickListener { player.pause() }
        findViewById<Button>(R.id.btnStop).setOnClickListener {
            player.pause()
            player.seekTo(0)
        }
        btnUpscale.setOnClickListener {
            upscaleMode = (upscaleMode + 1) % 4
            when (upscaleMode) {
                0 -> { renderer.upscaleHeight = PlayerRenderer.UPSCALE_AUTO; btnUpscale.text = "Upscale Layar" }
                1 -> { renderer.upscaleHeight = 2160; btnUpscale.text = "Upscale 4K" }
                2 -> { renderer.upscaleHeight = 1440; btnUpscale.text = "Upscale 1440p" }
                else -> { renderer.upscaleHeight = 0; btnUpscale.text = "Upscale OFF" }
            }
        }
        btnSr.setOnClickListener {
            if (!renderer.srAvailable) {
                Toast.makeText(this, "GPU ini menolak shader Super Resolution", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            renderer.superRes = !renderer.superRes
            btnSr.text = if (renderer.superRes) "SR: FSR" else "SR: Klasik"
        }
        btnFps.setOnClickListener {
            renderer.interpolate = !renderer.interpolate
            btnFps.text = if (renderer.interpolate) "120 FPS ON" else "120 FPS OFF"
        }

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) timeCur.text = fmt(progress.toLong())
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                seeking = true
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                seeking = false
                player.seekTo((sb?.progress ?: 0).toLong())
            }
        })

        intent?.data?.let { play(it) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.data?.let { play(it) }
    }

    override fun onResume() {
        super.onResume()
        glView.onResume()
        hideSystemBars()
        requestHighRefreshMode()
        ui.post(tick)
    }

    override fun onPause() {
        ui.removeCallbacks(tick)
        player.pause()
        player.clearVideoSurface()
        glView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        player.release()
        super.onDestroy()
    }

    private fun play(uri: Uri) {
        currentName = uri.lastPathSegment ?: "video"
        player.setMediaItem(MediaItem.fromUri(uri))
        player.prepare()
        player.playWhenReady = true
    }

    private fun updateUi() {
        val dur = player.duration
        if (dur > 0) {
            seek.max = dur.toInt()
            timeTotal.text = fmt(dur)
        }
        if (!seeking) {
            seek.progress = player.currentPosition.toInt().coerceAtLeast(0)
            timeCur.text = fmt(player.currentPosition)
        }
        if (renderer.srcW > 0) {
            @Suppress("DEPRECATION")
            val hz = windowManager.defaultDisplay.refreshRate
            val fps = renderer.measuredFps
            val draw = renderer.drawFps
            val algo = when {
                renderer.upscaleHeight == 0 -> "upscale off"
                renderer.outW <= renderer.srcW && renderer.outH <= renderer.srcH -> "tanpa upscale"
                renderer.srActive -> "SR: EASU+RCAS"
                else -> "Klasik"
            }
            val warn = if (renderer.interpolate && draw > 0f && draw < hz * 0.85f) "  ⚠ render < layar" else ""
            val line1 = "$currentName | ${renderer.srcW}x${renderer.srcH} → ${renderer.outW}x${renderer.outH} ($algo)"
            val line2 = "Video %s | Render %s | Layar %.0f Hz%s".format(fmtFps(fps), fmtFps(draw), hz, warn)
            status.text = line1 + "\n" + line2
        }
    }

    private fun fmtFps(f: Float): String = if (f > 0f) "%.0f fps".format(f) else "-- fps"

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
    }

    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    /** Minta layar berjalan di refresh rate tertinggi (mis. 120 Hz) pada resolusi yang sama. */
    private fun requestHighRefreshMode() {
        try {
            @Suppress("DEPRECATION")
            val disp = windowManager.defaultDisplay
            val m = disp.mode
            val best = disp.supportedModes
                .filter { it.physicalWidth == m.physicalWidth && it.physicalHeight == m.physicalHeight }
                .maxByOrNull { it.refreshRate }
            if (best != null) {
                val lp = window.attributes
                lp.preferredDisplayModeId = best.modeId
                lp.preferredRefreshRate = best.refreshRate
                maxHz = best.refreshRate
                window.attributes = lp
            }
        } catch (_: Throwable) {
        }
    }

    private fun requestSurfaceRate(holder: SurfaceHolder) {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val surface = holder.surface
                if (!surface.isValid) return
                if (Build.VERSION.SDK_INT >= 31) {
                    surface.setFrameRate(
                        maxHz, Surface.FRAME_RATE_COMPATIBILITY_DEFAULT, Surface.CHANGE_FRAME_RATE_ALWAYS
                    )
                } else {
                    surface.setFrameRate(maxHz, Surface.FRAME_RATE_COMPATIBILITY_DEFAULT)
                }
            } catch (_: Throwable) {
            }
        }
    }
}
