package com.pixelplayer

import android.graphics.SurfaceTexture
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.util.Log
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.max
import kotlin.math.min

/**
 * Pipeline GPU Pixel Player (OpenGL ES 3.0):
 *
 *  1. Frame video baru (24/30/60 fps) masuk dari MediaCodec lewat SurfaceTexture.
 *  1b. Frame OES (YUV) disalin SEKALI ke texture RGB biasa (resolusi sumber) supaya semua pass
 *     berikutnya memakai sampler2D yang murah.
 *  2. UPSCALE  : Super Resolution (EASU + RCAS, algoritma FSR 1.0) atau Catmull-Rom klasik
 *     -> texture besar. Target default = resolusi layar (4K / 1440p bisa dipilih manual).
 *  3. ESTIMASI GERAK : frame diperkecil, lalu block-matching mencari vektor gerak antara
 *     frame sebelumnya dan frame sekarang (sekali per frame video).
 *  4. INTERPOLASI : di SETIAP vsync layar (sampai 120 Hz) dibuat frame perantara
 *     motion-compensated antara frame lama dan baru -> gerakan jadi 120 fps.
 */
class PlayerRenderer(private val onSurfaceReady: (Surface) -> Unit) :
    GLSurfaceView.Renderer, SurfaceTexture.OnFrameAvailableListener {

    @Volatile var interpolate = true

    /** UPSCALE_AUTO = ikuti resolusi layar, 0 = off, 1440 / 2160 = target tinggi tetap. */
    @Volatile var upscaleHeight = UPSCALE_AUTO

    /** true = Super Resolution (EASU + RCAS), false = Catmull-Rom klasik. */
    @Volatile var superRes = true

    /** false bila shader SR gagal dikompilasi di GPU ini. */
    @Volatile var srAvailable = true
        private set

    /** true bila frame terakhir benar-benar diproses lewat jalur SR. */
    @Volatile var srActive = false
        private set

    /** Jumlah onDrawFrame per detik = fps keluaran yang SEBENARNYA dirender. */
    @Volatile var drawFps = 0f
        private set

    @Volatile var srcW = 0
        private set
    @Volatile var srcH = 0
        private set
    @Volatile var outW = 0
        private set
    @Volatile var outH = 0
        private set
    @Volatile var measuredFps = 0f
        private set

    @Volatile private var pixelRatio = 1f
    @Volatile private var dropFrame = false
    @Volatile private var resetTiming = true

    private val frameAvailable = AtomicBoolean(false)
    private var surfaceTexture: SurfaceTexture? = null
    private var surface: Surface? = null
    private var oesTex = 0
    private val texMat = FloatArray(16)
    private var haveSurfaceFrame = false

    private var surfW = 1
    private var surfH = 1

    private var progBlit = 0
    private var progEasu = 0
    private var progRcas = 0
    private var progUpscale = 0
    private var progLuma = 0
    private var progMe = 0
    private var progShow = 0
    private var vbo = 0

    private val srcTex = IntArray(2)
    private val srcFbo = IntArray(2)
    private var tmpTex = 0
    private var tmpFbo = 0
    private val bigTex = IntArray(2)
    private val bigFbo = IntArray(2)
    private val smallTex = IntArray(2)
    private val smallFbo = IntArray(2)
    private var mvTex = 0
    private var mvFbo = 0

    private var allocSrcW = 0
    private var allocSrcH = 0
    private var allocOutW = 0
    private var allocOutH = 0
    private var workW = 0
    private var workH = 0
    private var mvW = 0
    private var mvH = 0

    private var cur = 0
    private var haveFrame = false
    private var havePrev = false
    private var mvReady = false
    private var lastFrameNs = 0L
    private var intervalNs = 33_333_333.0
    private var maxTexSize = 4096
    private var fpsWindowStart = 0L
    private var fpsCount = 0

    fun setVideo(w: Int, h: Int, ratio: Float) {
        if (w != srcW || h != srcH) dropFrame = true
        srcW = w
        srcH = h
        pixelRatio = if (ratio > 0f) ratio else 1f
        resetTiming = true
    }

    override fun onFrameAvailable(st: SurfaceTexture?) {
        frameAvailable.set(true)
    }

    // ------------------------------------------------------------------ GL lifecycle

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        // Context baru => semua object GL lama tidak valid
        surface?.release()
        surfaceTexture?.release()
        allocSrcW = 0; allocSrcH = 0; allocOutW = 0; allocOutH = 0
        // ID texture/FBO lama milik context lama -> jangan di-delete lagi di context baru
        srcTex.fill(0); srcFbo.fill(0); tmpTex = 0; tmpFbo = 0
        bigTex.fill(0); bigFbo.fill(0); smallTex.fill(0); smallFbo.fill(0); mvTex = 0; mvFbo = 0
        haveFrame = false; havePrev = false; mvReady = false; haveSurfaceFrame = false
        frameAvailable.set(false)

        val quad = floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)
        val fb = ByteBuffer.allocateDirect(quad.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        fb.put(quad).position(0)
        val b = IntArray(1)
        GLES20.glGenBuffers(1, b, 0)
        vbo = b[0]
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, quad.size * 4, fb, GLES20.GL_STATIC_DRAW)
        GLES20.glEnableVertexAttribArray(0)
        GLES20.glVertexAttribPointer(0, 2, GLES20.GL_FLOAT, false, 0, 0)

        val mt = IntArray(1)
        GLES20.glGetIntegerv(GLES20.GL_MAX_TEXTURE_SIZE, mt, 0)
        maxTexSize = if (mt[0] > 0) mt[0] else 4096

        progBlit = program(VS, FS_BLIT)
        progUpscale = program(VS, FS_UPSCALE)
        progLuma = program(VS, FS_LUMA)
        progMe = program(VS, FS_ME)
        progShow = program(VS, FS_SHOW)

        // Super Resolution opsional: kalau GPU menolak shader-nya, app tetap jalan dengan upscaler klasik
        progEasu = 0
        progRcas = 0
        try {
            progEasu = program(VS, FS_EASU)
            progRcas = program(VS, FS_RCAS)
            srAvailable = true
        } catch (e: RuntimeException) {
            Log.e("PixelPlayer", "Shader Super Resolution gagal: ${e.message}")
            progEasu = 0
            progRcas = 0
            srAvailable = false
        }

        val t = IntArray(1)
        GLES20.glGenTextures(1, t, 0)
        oesTex = t[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTex)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

        val st = SurfaceTexture(oesTex)
        st.setOnFrameAvailableListener(this)
        surfaceTexture = st
        val s = Surface(st)
        surface = s
        onSurfaceReady(s)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        surfW = max(1, width)
        surfH = max(1, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        val st = surfaceTexture ?: return
        countDraw()

        if (resetTiming) {
            resetTiming = false
            havePrev = false
            mvReady = false
        }
        if (dropFrame) {
            dropFrame = false
            haveSurfaceFrame = false
            haveFrame = false
            havePrev = false
            mvReady = false
        }

        if (srcW <= 0 || srcH <= 0) {
            if (frameAvailable.getAndSet(false)) st.updateTexImage()
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
            GLES20.glViewport(0, 0, surfW, surfH)
            GLES20.glClearColor(0f, 0f, 0f, 1f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            return
        }

        ensureTargets()
        if (frameAvailable.getAndSet(false)) onNewFrame(st)
        draw()
    }

    // ------------------------------------------------------------------ targets

    /** Tinggi video (px) bila di-fit ke surface layar. */
    private fun fitHeight(sw: Int, sh: Int): Int {
        val va = sw * pixelRatio / sh
        var h = (surfW / va).toInt()
        if (h > surfH) h = surfH
        return max(1, h)
    }

    private fun ensureTargets() {
        val sw = srcW
        val sh = srcH
        var ow = sw
        var oh = sh
        val uh = upscaleHeight
        if (uh != 0) {
            val scale = if (uh < 0) {
                // Ikuti layar: upscale tepat ke resolusi yang benar-benar tampil
                max(1f, fitHeight(sw, sh).toFloat() / sh)
            } else {
                val maxW = uh * 16f / 9f
                val maxH = uh.toFloat()
                max(1f, min(maxW / sw, maxH / sh))
            }
            ow = (sw * scale).toInt()
            oh = (sh * scale).toInt()
        }
        val lim = maxTexSize
        if (ow > lim || oh > lim) {
            val k = lim.toFloat() / max(ow, oh)
            ow = (ow * k).toInt()
            oh = (oh * k).toInt()
        }
        ow = max(2, ow and 1.inv())
        oh = max(2, oh and 1.inv())

        if (sw == allocSrcW && sh == allocSrcH && ow == allocOutW && oh == allocOutH) return

        freeTargets()
        for (i in 0..1) {
            srcTex[i] = createTex(sw, sh)
            srcFbo[i] = createFbo(srcTex[i])
            bigTex[i] = createTex(ow, oh)
            bigFbo[i] = createFbo(bigTex[i])
        }
        if (srAvailable) {
            tmpTex = createTex(ow, oh)
            tmpFbo = createFbo(tmpTex)
        }
        workW = max(16, (sw / 4) / 4 * 4)
        workH = max(16, (sh / 4) / 4 * 4)
        for (i in 0..1) {
            smallTex[i] = createTex(workW, workH)
            smallFbo[i] = createFbo(smallTex[i])
        }
        mvW = workW / 4
        mvH = workH / 4
        mvTex = createTex(mvW, mvH)
        mvFbo = createFbo(mvTex)

        allocSrcW = sw; allocSrcH = sh; allocOutW = ow; allocOutH = oh
        outW = ow; outH = oh
        havePrev = false
        mvReady = false
        haveFrame = false

        if (haveSurfaceFrame) {
            // OES texture masih menyimpan frame terakhir -> gambar ulang ke target baru
            cur = 0
            renderSource(cur)
            haveFrame = true
            lastFrameNs = System.nanoTime()
        }
    }

    private fun freeTargets() {
        if (bigTex[0] != 0) {
            GLES20.glDeleteTextures(2, srcTex, 0)
            GLES20.glDeleteFramebuffers(2, srcFbo, 0)
            if (tmpTex != 0) {
                GLES20.glDeleteTextures(1, intArrayOf(tmpTex), 0)
                GLES20.glDeleteFramebuffers(1, intArrayOf(tmpFbo), 0)
                tmpTex = 0; tmpFbo = 0
            }
            GLES20.glDeleteTextures(2, bigTex, 0)
            GLES20.glDeleteFramebuffers(2, bigFbo, 0)
            GLES20.glDeleteTextures(2, smallTex, 0)
            GLES20.glDeleteFramebuffers(2, smallFbo, 0)
            GLES20.glDeleteTextures(1, intArrayOf(mvTex), 0)
            GLES20.glDeleteFramebuffers(1, intArrayOf(mvFbo), 0)
        }
    }

    private fun createTex(w: Int, h: Int): Int {
        val t = IntArray(1)
        GLES20.glGenTextures(1, t, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, t[0])
        GLES20.glTexImage2D(
            GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, w, h, 0,
            GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null
        )
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        return t[0]
    }

    private fun createFbo(tex: Int): Int {
        val f = IntArray(1)
        GLES20.glGenFramebuffers(1, f, 0)
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, f[0])
        GLES20.glFramebufferTexture2D(
            GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, tex, 0
        )
        return f[0]
    }

    // ------------------------------------------------------------------ per video frame

    private fun onNewFrame(st: SurfaceTexture) {
        st.updateTexImage()
        st.getTransformMatrix(texMat)
        haveSurfaceFrame = true

        val now = System.nanoTime()
        var gapOk = false
        if (haveFrame) {
            val gap = now - lastFrameNs
            gapOk = gap < 250_000_000L
            if (gapOk && gap >= 4_000_000L) {
                val g = gap.toDouble().coerceIn(intervalNs * 0.5, intervalNs * 2.0)
                intervalNs = intervalNs * 0.9 + g * 0.1
                measuredFps = (1e9 / intervalNs).toFloat()
            }
        }

        cur = 1 - cur
        renderSource(cur)

        havePrev = haveFrame && gapOk
        mvReady = false
        if (havePrev && interpolate) {
            runMotionEstimation()
            mvReady = true
        }
        haveFrame = true
        lastFrameNs = now
    }

    /**
     * 1) OES -> srcTex (RGB biasa, resolusi sumber)
     * 2) upscale -> bigTex[slot]  (SR: EASU -> tmp -> RCAS, atau Catmull-Rom klasik)
     * 3) versi kecil (luma) -> smallTex[slot] untuk estimasi gerak
     */
    private fun renderSource(slot: Int) {
        val sw = allocSrcW
        val sh = allocSrcH
        val ow = allocOutW
        val oh = allocOutH

        // 1) salin frame decoder ke texture RGB biasa
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTex)
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, srcFbo[slot])
        GLES20.glViewport(0, 0, sw, sh)
        GLES20.glUseProgram(progBlit)
        GLES20.glUniform1i(loc(progBlit, "uTex"), 0)
        GLES20.glUniformMatrix4fv(loc(progBlit, "uTexMat"), 1, false, texMat, 0)
        drawQuad()

        // 2) upscale
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, srcTex[slot])
        val upscaling = ow > sw || oh > sh
        val useSr = superRes && srAvailable && progEasu != 0 && tmpTex != 0 && upscaling
        srActive = useSr
        if (useSr) {
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, tmpFbo)
            GLES20.glViewport(0, 0, ow, oh)
            GLES20.glUseProgram(progEasu)
            GLES20.glUniform1i(loc(progEasu, "uSrc"), 0)
            GLES20.glUniform2f(loc(progEasu, "uSrcSize"), sw.toFloat(), sh.toFloat())
            drawQuad()

            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tmpTex)
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, bigFbo[slot])
            GLES20.glViewport(0, 0, ow, oh)
            GLES20.glUseProgram(progRcas)
            GLES20.glUniform1i(loc(progRcas, "uTex"), 0)
            GLES20.glUniform2f(loc(progRcas, "uOutSize"), ow.toFloat(), oh.toFloat())
            GLES20.glUniform1f(loc(progRcas, "uCon"), RCAS_CON)
            drawQuad()
        } else {
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, bigFbo[slot])
            GLES20.glViewport(0, 0, ow, oh)
            GLES20.glUseProgram(progUpscale)
            GLES20.glUniform1i(loc(progUpscale, "uTex"), 0)
            GLES20.glUniform2f(loc(progUpscale, "uSrcSize"), sw.toFloat(), sh.toFloat())
            GLES20.glUniform1f(loc(progUpscale, "uSharp"), if (upscaling) 0.6f else 0.0f)
            drawQuad()
        }

        // 3) luma kecil untuk motion estimation
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, srcTex[slot])
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, smallFbo[slot])
        GLES20.glViewport(0, 0, workW, workH)
        GLES20.glUseProgram(progLuma)
        GLES20.glUniform1i(loc(progLuma, "uTex"), 0)
        GLES20.glUniform2f(loc(progLuma, "uSrcSize"), sw.toFloat(), sh.toFloat())
        drawQuad()
    }

    private fun runMotionEstimation() {
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, mvFbo)
        GLES20.glViewport(0, 0, mvW, mvH)
        GLES20.glUseProgram(progMe)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, smallTex[cur])
        GLES20.glActiveTexture(GLES20.GL_TEXTURE1)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, smallTex[1 - cur])
        GLES20.glUniform1i(loc(progMe, "uCur"), 0)
        GLES20.glUniform1i(loc(progMe, "uPrev"), 1)
        GLES20.glUniform2i(loc(progMe, "uWorkSize"), workW, workH)
        drawQuad()
    }

    // ------------------------------------------------------------------ per vsync

    private fun draw() {
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
        GLES20.glViewport(0, 0, surfW, surfH)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        if (!haveFrame) return

        val va = srcW * pixelRatio / srcH
        var w = surfW
        var h = (w / va).toInt()
        if (h > surfH) {
            h = surfH
            w = (h * va).toInt()
        }
        GLES20.glViewport((surfW - w) / 2, (surfH - h) / 2, max(1, w), max(1, h))

        val useMv = mvReady && interpolate
        val t = if (useMv) {
            ((System.nanoTime() - lastFrameNs) / intervalNs).toFloat().coerceIn(0f, 1f)
        } else 1f

        GLES20.glUseProgram(progShow)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, bigTex[1 - cur])
        GLES20.glActiveTexture(GLES20.GL_TEXTURE1)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, bigTex[cur])
        GLES20.glActiveTexture(GLES20.GL_TEXTURE2)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, mvTex)
        GLES20.glUniform1i(loc(progShow, "uA"), 0)
        GLES20.glUniform1i(loc(progShow, "uB"), 1)
        GLES20.glUniform1i(loc(progShow, "uMv"), 2)
        GLES20.glUniform1f(loc(progShow, "uT"), t)
        GLES20.glUniform1f(loc(progShow, "uUseMv"), if (useMv) 1f else 0f)
        GLES20.glUniform2f(loc(progShow, "uWorkSize"), workW.toFloat(), workH.toFloat())
        drawQuad()
    }

    // ------------------------------------------------------------------ helpers

    private fun countDraw() {
        val now = System.nanoTime()
        if (fpsWindowStart == 0L) fpsWindowStart = now
        fpsCount++
        val dt = now - fpsWindowStart
        if (dt >= 1_000_000_000L) {
            drawFps = fpsCount * 1e9f / dt
            fpsCount = 0
            fpsWindowStart = now
        }
    }

    private fun drawQuad() = GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

    private fun loc(p: Int, n: String) = GLES20.glGetUniformLocation(p, n)

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(s)
            GLES20.glDeleteShader(s)
            throw RuntimeException("Shader error: $log")
        }
        return s
    }

    private fun program(vs: String, fs: String): Int {
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("Link error: " + GLES20.glGetProgramInfoLog(p))
        return p
    }

    companion object {
        const val UPSCALE_AUTO = -1
        private const val RCAS_CON = 0.85f // exp2(-sharpness): kecil = lebih tajam

        private const val VS = """#version 300 es
layout(location = 0) in vec2 aPos;
out vec2 vUv;
void main() {
    vUv = aPos * 0.5 + 0.5;
    gl_Position = vec4(aPos, 0.0, 1.0);
}
"""

        // Upscaler: bicubic Catmull-Rom (9 tap) + unsharp mask dengan batas min/max lokal (anti ringing)
        private const val FS_UPSCALE = """#version 300 es
precision highp float;
uniform sampler2D uTex;
uniform vec2 uSrcSize;
uniform float uSharp;
in vec2 vUv;
out vec4 o;

vec3 fetch(vec2 p) { return texture(uTex, p).rgb; }

void main() {
    vec2 uv = vUv;
    vec2 sp = uv * uSrcSize;
    vec2 t1 = floor(sp - 0.5) + 0.5;
    vec2 f = sp - t1;
    vec2 w0 = f * (-0.5 + f * (1.0 - 0.5 * f));
    vec2 w1 = 1.0 + f * f * (-2.5 + 1.5 * f);
    vec2 w2 = f * (0.5 + f * (2.0 - 1.5 * f));
    vec2 w3 = f * f * (-0.5 + 0.5 * f);
    vec2 w12 = w1 + w2;
    vec2 o12 = w2 / w12;
    vec2 p0 = (t1 - 1.0) / uSrcSize;
    vec2 p3 = (t1 + 2.0) / uSrcSize;
    vec2 p12 = (t1 + o12) / uSrcSize;

    vec3 bic = vec3(0.0);
    bic += fetch(vec2(p0.x,  p0.y))  * w0.x  * w0.y;
    bic += fetch(vec2(p12.x, p0.y))  * w12.x * w0.y;
    bic += fetch(vec2(p3.x,  p0.y))  * w3.x  * w0.y;
    bic += fetch(vec2(p0.x,  p12.y)) * w0.x  * w12.y;
    bic += fetch(vec2(p12.x, p12.y)) * w12.x * w12.y;
    bic += fetch(vec2(p3.x,  p12.y)) * w3.x  * w12.y;
    bic += fetch(vec2(p0.x,  p3.y))  * w0.x  * w3.y;
    bic += fetch(vec2(p12.x, p3.y))  * w12.x * w3.y;
    bic += fetch(vec2(p3.x,  p3.y))  * w3.x  * w3.y;

    if (uSharp <= 0.0) { o = vec4(clamp(bic, 0.0, 1.0), 1.0); return; }

    vec2 px = 1.0 / uSrcSize;
    vec3 c  = fetch(uv);
    vec3 n1 = fetch(uv + vec2(px.x, 0.0));
    vec3 n2 = fetch(uv - vec2(px.x, 0.0));
    vec3 n3 = fetch(uv + vec2(0.0, px.y));
    vec3 n4 = fetch(uv - vec2(0.0, px.y));
    vec3 blur = (n1 + n2 + n3 + n4) * 0.25;
    vec3 mn = min(min(min(n1, n2), min(n3, n4)), c);
    vec3 mx = max(max(max(n1, n2), max(n3, n4)), c);
    vec3 r = bic + uSharp * (c - blur);
    r = clamp(r, mn, mx);
    o = vec4(clamp(r, 0.0, 1.0), 1.0);
}
"""

        // Versi kecil (1/4) dalam luma untuk estimasi gerak
        private const val FS_LUMA = """#version 300 es
precision highp float;
uniform sampler2D uTex;
uniform vec2 uSrcSize;
in vec2 vUv;
out vec4 o;
void main() {
    vec2 uv = vUv;
    vec2 st = 1.0 / uSrcSize;
    vec3 c = texture(uTex, uv + vec2(-st.x, -st.y)).rgb
           + texture(uTex, uv + vec2( st.x, -st.y)).rgb
           + texture(uTex, uv + vec2(-st.x,  st.y)).rgb
           + texture(uTex, uv + vec2( st.x,  st.y)).rgb;
    c *= 0.25;
    float l = dot(c, vec3(0.299, 0.587, 0.114));
    o = vec4(l, l, l, 1.0);
}
"""

        // Block matching 4x4 (resolusi kecil): coarse step 2 pada +-8, lalu refine +-1.
        // Hasil: rg = vektor (d/10*0.5+0.5), b = SAD ter-normalisasi.
        // Arti vektor d: B(x) ~= A(x + d)
        private const val FS_ME = """#version 300 es
precision highp float;
precision highp int;
uniform sampler2D uCur;
uniform sampler2D uPrev;
uniform ivec2 uWorkSize;
out vec4 o;

float blockCost(ivec2 base, ivec2 d) {
    float s = 0.0;
    for (int y = 0; y < 4; y++) {
        for (int x = 0; x < 4; x++) {
            ivec2 p = base + ivec2(x, y);
            ivec2 q = clamp(p + d, ivec2(0), uWorkSize - 1);
            s += abs(texelFetch(uCur, p, 0).r - texelFetch(uPrev, q, 0).r);
        }
    }
    return s / 16.0;
}

void main() {
    ivec2 base = ivec2(gl_FragCoord.xy) * 4;
    ivec2 best = ivec2(0);
    float bestSad = blockCost(base, best);
    float bestCost = bestSad;

    for (int dy = -8; dy <= 8; dy += 2) {
        for (int dx = -8; dx <= 8; dx += 2) {
            ivec2 d = ivec2(dx, dy);
            float c = blockCost(base, d);
            float cost = c + 0.004 * length(vec2(d));
            if (cost < bestCost) { bestCost = cost; best = d; bestSad = c; }
        }
    }
    ivec2 center = best;
    for (int dy = -1; dy <= 1; dy++) {
        for (int dx = -1; dx <= 1; dx++) {
            ivec2 d = center + ivec2(dx, dy);
            float c = blockCost(base, d);
            float cost = c + 0.004 * length(vec2(d));
            if (cost < bestCost) { bestCost = cost; best = d; bestSad = c; }
        }
    }
    vec2 enc = vec2(best) / 10.0 * 0.5 + 0.5;
    o = vec4(enc, clamp(bestSad * 5.0, 0.0, 1.0), 1.0);
}
"""

        // Frame perantara motion-compensated; fallback ke cross-fade bila gerak tidak bisa dipercaya
        // (scene cut / oklusi).
        private const val FS_SHOW = """#version 300 es
precision highp float;
uniform sampler2D uA;
uniform sampler2D uB;
uniform sampler2D uMv;
uniform float uT;
uniform float uUseMv;
uniform vec2 uWorkSize;
in vec2 vUv;
out vec4 o;
void main() {
    vec3 a0 = texture(uA, vUv).rgb;
    vec3 b0 = texture(uB, vUv).rgb;
    if (uUseMv < 0.5) { o = vec4(b0, 1.0); return; }
    vec4 e = texture(uMv, vUv);
    vec2 d = (e.rg * 2.0 - 1.0) * 10.0;
    vec2 duv = d / uWorkSize;
    vec3 a = texture(uA, vUv + uT * duv).rgb;
    vec3 b = texture(uB, vUv - (1.0 - uT) * duv).rgb;
    vec3 mc = mix(a, b, uT);
    // Gerak tidak bisa dipercaya -> cross-fade A/B (bukan 'hold', karena hold = terlihat 30 fps)
    vec3 fallback = mix(a0, b0, uT);
    float conf = 1.0 - smoothstep(0.35, 0.8, e.b);
    float agree = 1.0 - smoothstep(0.12, 0.35, length(a - b));
    o = vec4(mix(fallback, mc, conf * agree), 1.0);
}
"""

        // Salin frame decoder (OES/YUV) -> RGB biasa, sekali per frame video
        private const val FS_BLIT = """#version 300 es
#extension GL_OES_EGL_image_external_essl3 : require
precision highp float;
uniform samplerExternalOES uTex;
uniform mat4 uTexMat;
in vec2 vUv;
out vec4 o;
void main() {
    vec2 uv = (uTexMat * vec4(vUv, 0.0, 1.0)).xy;
    o = vec4(texture(uTex, uv).rgb, 1.0);
}
"""

        // Super Resolution pass 1: EASU (Edge Adaptive Spatial Upsampling), 12 tap, kernel Lanczos-like
        // yang diputar & dipanjangkan mengikuti arah tepi. Berdasarkan AMD FidelityFX FSR 1.0 (MIT).
        private const val FS_EASU = """#version 300 es
precision highp float;
precision highp int;
uniform sampler2D uSrc;
uniform vec2 uSrcSize;
in vec2 vUv;
out vec4 o;

ivec2 isz;

vec3 ld(ivec2 p) { return texelFetch(uSrc, clamp(p, ivec2(0), isz - 1), 0).rgb; }
float lm(vec3 c) { return c.b * 0.5 + (c.r * 0.5 + c.g); }

void easuSet(inout vec2 dir, inout float len, float w,
             float lA, float lB, float lC, float lD, float lE) {
    float dc = lD - lC;
    float cb = lC - lB;
    float lenX = 1.0 / max(max(abs(dc), abs(cb)), 1.0 / 65536.0);
    float dirX = lD - lB;
    dir.x += dirX * w;
    lenX = clamp(abs(dirX) * lenX, 0.0, 1.0);
    lenX *= lenX;
    len += lenX * w;

    float ec = lE - lC;
    float ca = lC - lA;
    float lenY = 1.0 / max(max(abs(ec), abs(ca)), 1.0 / 65536.0);
    float dirY = lE - lA;
    dir.y += dirY * w;
    lenY = clamp(abs(dirY) * lenY, 0.0, 1.0);
    lenY *= lenY;
    len += lenY * w;
}

void easuTap(inout vec3 aC, inout float aW, vec2 off, vec2 dir, vec2 len,
             float lob, float clp, vec3 c) {
    vec2 v;
    v.x = off.x * dir.x + off.y * dir.y;
    v.y = off.x * (-dir.y) + off.y * dir.x;
    v *= len;
    float d2 = min(v.x * v.x + v.y * v.y, clp);
    float wB = 2.0 / 5.0 * d2 - 1.0;
    float wA = lob * d2 - 1.0;
    wB *= wB;
    wA *= wA;
    wB = 25.0 / 16.0 * wB - (25.0 / 16.0 - 1.0);
    float w = wB * wA;
    aC += c * w;
    aW += w;
}

void main() {
    isz = ivec2(uSrcSize + 0.5);
    vec2 pp = vUv * uSrcSize - 0.5;
    vec2 fp = floor(pp);
    pp -= fp;
    ivec2 i0 = ivec2(fp);

    //    b c
    //  e f g h
    //  i j k l
    //    n o
    vec3 b = ld(i0 + ivec2( 0, -1));
    vec3 c = ld(i0 + ivec2( 1, -1));
    vec3 e = ld(i0 + ivec2(-1,  0));
    vec3 f = ld(i0);
    vec3 g = ld(i0 + ivec2( 1,  0));
    vec3 h = ld(i0 + ivec2( 2,  0));
    vec3 i = ld(i0 + ivec2(-1,  1));
    vec3 j = ld(i0 + ivec2( 0,  1));
    vec3 k = ld(i0 + ivec2( 1,  1));
    vec3 l = ld(i0 + ivec2( 2,  1));
    vec3 n = ld(i0 + ivec2( 0,  2));
    vec3 oo = ld(i0 + ivec2( 1,  2));

    float bL = lm(b), cL = lm(c), eL = lm(e), fL = lm(f), gL = lm(g), hL = lm(h);
    float iL = lm(i), jL = lm(j), kL = lm(k), lL = lm(l), nL = lm(n), oL = lm(oo);

    vec2 dir = vec2(0.0);
    float len = 0.0;
    easuSet(dir, len, (1.0 - pp.x) * (1.0 - pp.y), bL, eL, fL, gL, jL);
    easuSet(dir, len, pp.x * (1.0 - pp.y),         cL, fL, gL, hL, kL);
    easuSet(dir, len, (1.0 - pp.x) * pp.y,         fL, iL, jL, kL, nL);
    easuSet(dir, len, pp.x * pp.y,                 gL, jL, kL, lL, oL);

    float dirR = dir.x * dir.x + dir.y * dir.y;
    bool zro = dirR < (1.0 / 32768.0);
    dirR = inversesqrt(max(dirR, 1.0 / 32768.0));
    dirR = zro ? 1.0 : dirR;
    dir.x = zro ? 1.0 : dir.x;
    dir *= vec2(dirR);

    len = len * 0.5;
    len *= len;
    float stretch = (dir.x * dir.x + dir.y * dir.y) / max(abs(dir.x), abs(dir.y));
    vec2 len2 = vec2(1.0 + (stretch - 1.0) * len, 1.0 - 0.5 * len);
    float lob = 0.5 + ((1.0 / 4.0 - 0.04) - 0.5) * len;
    float clp = 1.0 / lob;

    vec3 min4 = min(min(f, g), min(j, k));
    vec3 max4 = max(max(f, g), max(j, k));

    vec3 aC = vec3(0.0);
    float aW = 0.0;
    easuTap(aC, aW, vec2( 0.0, -1.0) - pp, dir, len2, lob, clp, b);
    easuTap(aC, aW, vec2( 1.0, -1.0) - pp, dir, len2, lob, clp, c);
    easuTap(aC, aW, vec2(-1.0,  1.0) - pp, dir, len2, lob, clp, i);
    easuTap(aC, aW, vec2( 0.0,  1.0) - pp, dir, len2, lob, clp, j);
    easuTap(aC, aW, vec2( 0.0,  0.0) - pp, dir, len2, lob, clp, f);
    easuTap(aC, aW, vec2(-1.0,  0.0) - pp, dir, len2, lob, clp, e);
    easuTap(aC, aW, vec2( 1.0,  1.0) - pp, dir, len2, lob, clp, k);
    easuTap(aC, aW, vec2( 2.0,  1.0) - pp, dir, len2, lob, clp, l);
    easuTap(aC, aW, vec2( 2.0,  0.0) - pp, dir, len2, lob, clp, h);
    easuTap(aC, aW, vec2( 1.0,  0.0) - pp, dir, len2, lob, clp, g);
    easuTap(aC, aW, vec2( 1.0,  2.0) - pp, dir, len2, lob, clp, oo);
    easuTap(aC, aW, vec2( 0.0,  2.0) - pp, dir, len2, lob, clp, n);

    vec3 res = (aW > 1e-4) ? (aC / aW) : f;
    res = clamp(res, min4, max4);   // anti-ringing
    o = vec4(clamp(res, 0.0, 1.0), 1.0);
}
"""

        // Super Resolution pass 2: RCAS (Robust Contrast Adaptive Sharpening), 5 tap, tanpa halo
        private const val FS_RCAS = """#version 300 es
precision highp float;
precision highp int;
uniform sampler2D uTex;
uniform vec2 uOutSize;
uniform float uCon;
in vec2 vUv;
out vec4 o;

void main() {
    ivec2 sz = ivec2(uOutSize + 0.5);
    ivec2 ip = ivec2(gl_FragCoord.xy);
    vec3 b = texelFetch(uTex, clamp(ip + ivec2( 0, -1), ivec2(0), sz - 1), 0).rgb;
    vec3 d = texelFetch(uTex, clamp(ip + ivec2(-1,  0), ivec2(0), sz - 1), 0).rgb;
    vec3 e = texelFetch(uTex, clamp(ip,                  ivec2(0), sz - 1), 0).rgb;
    vec3 f = texelFetch(uTex, clamp(ip + ivec2( 1,  0), ivec2(0), sz - 1), 0).rgb;
    vec3 h = texelFetch(uTex, clamp(ip + ivec2( 0,  1), ivec2(0), sz - 1), 0).rgb;

    float bL = b.b * 0.5 + (b.r * 0.5 + b.g);
    float dL = d.b * 0.5 + (d.r * 0.5 + d.g);
    float eL = e.b * 0.5 + (e.r * 0.5 + e.g);
    float fL = f.b * 0.5 + (f.r * 0.5 + f.g);
    float hL = h.b * 0.5 + (h.r * 0.5 + h.g);

    // deteksi noise: area noisy -> sharpen dikurangi
    float nz = 0.25 * (bL + dL + fL + hL) - eL;
    float rng = max(max(bL, dL), max(eL, max(fL, hL))) - min(min(bL, dL), min(eL, min(fL, hL)));
    nz = clamp(abs(nz) / max(rng, 1.0 / 1024.0), 0.0, 1.0);
    nz = -0.5 * nz + 1.0;

    vec3 mn4 = min(min(b, d), min(f, h));
    vec3 mx4 = max(max(b, d), max(f, h));
    vec3 hitMin = mn4 / max(4.0 * mx4, vec3(1.0 / 1024.0));
    vec3 hitMax = (1.0 - mx4) / min(4.0 * mn4 - 4.0, vec3(-1.0 / 1024.0));
    vec3 lobeRGB = max(-hitMin, hitMax);
    float lobe = max(-0.1875, min(max(lobeRGB.r, max(lobeRGB.g, lobeRGB.b)), 0.0)) * uCon;
    lobe *= nz;

    vec3 c = (lobe * (b + d + f + h) + e) / (4.0 * lobe + 1.0);
    o = vec4(clamp(c, 0.0, 1.0), 1.0);
}
"""
    }
}
