package com.pixelplayer

import android.graphics.SurfaceTexture
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.max
import kotlin.math.min

/**
 * Pipeline GPU Pixel Player (OpenGL ES 3.0):
 *
 *  1. Frame video baru (24/30/60 fps) masuk dari MediaCodec lewat SurfaceTexture.
 *  2. UPSCALE  : frame di-upscale ke 1440p/4K (Catmull-Rom + anti-ringing sharpen) -> texture besar.
 *  3. ESTIMASI GERAK : frame diperkecil, lalu block-matching mencari vektor gerak antara
 *     frame sebelumnya dan frame sekarang (sekali per frame video).
 *  4. INTERPOLASI : di SETIAP vsync layar (sampai 120 Hz) dibuat frame perantara
 *     motion-compensated antara frame lama dan baru -> gerakan jadi 120 fps.
 */
class PlayerRenderer(private val onSurfaceReady: (Surface) -> Unit) :
    GLSurfaceView.Renderer, SurfaceTexture.OnFrameAvailableListener {

    @Volatile var interpolate = true
    @Volatile var upscaleHeight = 2160 // 0 = off, 1440, 2160

    @Volatile var srcW = 0
        private set
    @Volatile var srcH = 0
        private set
    @Volatile var outW = 0
        private set
    @Volatile var outH = 0
        private set
    @Volatile var measuredFps = 0f
        private set

    @Volatile private var pixelRatio = 1f
    @Volatile private var dropFrame = false
    @Volatile private var resetTiming = true

    private val frameAvailable = AtomicBoolean(false)
    private var surfaceTexture: SurfaceTexture? = null
    private var surface: Surface? = null
    private var oesTex = 0
    private val texMat = FloatArray(16)
    private var haveSurfaceFrame = false

    private var surfW = 1
    private var surfH = 1

    private var progUpscale = 0
    private var progLuma = 0
    private var progMe = 0
    private var progShow = 0
    private var vbo = 0

    private val bigTex = IntArray(2)
    private val bigFbo = IntArray(2)
    private val smallTex = IntArray(2)
    private val smallFbo = IntArray(2)
    private var mvTex = 0
    private var mvFbo = 0

    private var allocSrcW = 0
    private var allocSrcH = 0
    private var allocOutW = 0
    private var allocOutH = 0
    private var workW = 0
    private var workH = 0
    private var mvW = 0
    private var mvH = 0

    private var cur = 0
    private var haveFrame = false
    private var havePrev = false
    private var mvReady = false
    private var lastFrameNs = 0L
    private var intervalNs = 33_333_333.0

    fun setVideo(w: Int, h: Int, ratio: Float) {
        if (w != srcW || h != srcH) dropFrame = true
        srcW = w
        srcH = h
        pixelRatio = if (ratio > 0f) ratio else 1f
        resetTiming = true
    }

    override fun onFrameAvailable(st: SurfaceTexture?) {
        frameAvailable.set(true)
    }

    // ------------------------------------------------------------------ GL lifecycle

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        // Context baru => semua object GL lama tidak valid
        surface?.release()
        surfaceTexture?.release()
        allocSrcW = 0; allocSrcH = 0; allocOutW = 0; allocOutH = 0
        haveFrame = false; havePrev = false; mvReady = false; haveSurfaceFrame = false
        frameAvailable.set(false)

        val quad = floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)
        val fb = ByteBuffer.allocateDirect(quad.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        fb.put(quad).position(0)
        val b = IntArray(1)
        GLES20.glGenBuffers(1, b, 0)
        vbo = b[0]
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, quad.size * 4, fb, GLES20.GL_STATIC_DRAW)
        GLES20.glEnableVertexAttribArray(0)
        GLES20.glVertexAttribPointer(0, 2, GLES20.GL_FLOAT, false, 0, 0)

        progUpscale = program(VS, FS_UPSCALE)
        progLuma = program(VS, FS_LUMA)
        progMe = program(VS, FS_ME)
        progShow = program(VS, FS_SHOW)

        val t = IntArray(1)
        GLES20.glGenTextures(1, t, 0)
        oesTex = t[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTex)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

        val st = SurfaceTexture(oesTex)
        st.setOnFrameAvailableListener(this)
        surfaceTexture = st
        val s = Surface(st)
        surface = s
        onSurfaceReady(s)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        surfW = max(1, width)
        surfH = max(1, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        val st = surfaceTexture ?: return

        if (resetTiming) {
            resetTiming = false
            havePrev = false
            mvReady = false
        }
        if (dropFrame) {
            dropFrame = false
            haveSurfaceFrame = false
            haveFrame = false
            havePrev = false
            mvReady = false
        }

        if (srcW <= 0 || srcH <= 0) {
            if (frameAvailable.getAndSet(false)) st.updateTexImage()
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
            GLES20.glViewport(0, 0, surfW, surfH)
            GLES20.glClearColor(0f, 0f, 0f, 1f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            return
        }

        ensureTargets()
        if (frameAvailable.getAndSet(false)) onNewFrame(st)
        draw()
    }

    // ------------------------------------------------------------------ targets

    private fun ensureTargets() {
        val sw = srcW
        val sh = srcH
        var ow = sw
        var oh = sh
        val uh = upscaleHeight
        if (uh > 0) {
            val maxW = uh * 16f / 9f
            val maxH = uh.toFloat()
            var scale = min(maxW / sw, maxH / sh)
            if (scale < 1f) scale = 1f
            ow = (sw * scale).toInt()
            oh = (sh * scale).toInt()
        }
        val mt = IntArray(1)
        GLES20.glGetIntegerv(GLES20.GL_MAX_TEXTURE_SIZE, mt, 0)
        val lim = mt[0]
        if (ow > lim || oh > lim) {
            val k = lim.toFloat() / max(ow, oh)
            ow = (ow * k).toInt()
            oh = (oh * k).toInt()
        }
        ow = max(2, ow and 1.inv())
        oh = max(2, oh and 1.inv())

        if (sw == allocSrcW && sh == allocSrcH && ow == allocOutW && oh == allocOutH) return

        freeTargets()
        for (i in 0..1) {
            bigTex[i] = createTex(ow, oh)
            bigFbo[i] = createFbo(bigTex[i])
        }
        workW = max(16, (sw / 4) / 4 * 4)
        workH = max(16, (sh / 4) / 4 * 4)
        for (i in 0..1) {
            smallTex[i] = createTex(workW, workH)
            smallFbo[i] = createFbo(smallTex[i])
        }
        mvW = workW / 4
        mvH = workH / 4
        mvTex = createTex(mvW, mvH)
        mvFbo = createFbo(mvTex)

        allocSrcW = sw; allocSrcH = sh; allocOutW = ow; allocOutH = oh
        outW = ow; outH = oh
        havePrev = false
        mvReady = false
        haveFrame = false

        if (haveSurfaceFrame) {
            // OES texture masih menyimpan frame terakhir -> gambar ulang ke target baru
            cur = 0
            renderSource(cur)
            haveFrame = true
            lastFrameNs = System.nanoTime()
        }
    }

    private fun freeTargets() {
        if (bigTex[0] != 0) {
            GLES20.glDeleteTextures(2, bigTex, 0)
            GLES20.glDeleteFramebuffers(2, bigFbo, 0)
            GLES20.glDeleteTextures(2, smallTex, 0)
            GLES20.glDeleteFramebuffers(2, smallFbo, 0)
            GLES20.glDeleteTextures(1, intArrayOf(mvTex), 0)
            GLES20.glDeleteFramebuffers(1, intArrayOf(mvFbo), 0)
        }
    }

    private fun createTex(w: Int, h: Int): Int {
        val t = IntArray(1)
        GLES20.glGenTextures(1, t, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, t[0])
        GLES20.glTexImage2D(
            GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, w, h, 0,
            GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null
        )
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        return t[0]
    }

    private fun createFbo(tex: Int): Int {
        val f = IntArray(1)
        GLES20.glGenFramebuffers(1, f, 0)
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, f[0])
        GLES20.glFramebufferTexture2D(
            GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, tex, 0
        )
        return f[0]
    }

    // ------------------------------------------------------------------ per video frame

    private fun onNewFrame(st: SurfaceTexture) {
        st.updateTexImage()
        st.getTransformMatrix(texMat)
        haveSurfaceFrame = true

        val now = System.nanoTime()
        var gapOk = false
        if (haveFrame) {
            val gap = now - lastFrameNs
            gapOk = gap < 250_000_000L
            if (gapOk && gap >= 4_000_000L) {
                val g = gap.toDouble().coerceIn(intervalNs * 0.5, intervalNs * 2.0)
                intervalNs = intervalNs * 0.9 + g * 0.1
                measuredFps = (1e9 / intervalNs).toFloat()
            }
        }

        cur = 1 - cur
        renderSource(cur)

        havePrev = haveFrame && gapOk
        mvReady = false
        if (havePrev && interpolate) {
            runMotionEstimation()
            mvReady = true
        }
        haveFrame = true
        lastFrameNs = now
    }

    /** Upscale frame ke bigTex[slot] dan buat versi kecil (luma) ke smallTex[slot]. */
    private fun renderSource(slot: Int) {
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTex)

        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, bigFbo[slot])
        GLES20.glViewport(0, 0, allocOutW, allocOutH)
        GLES20.glUseProgram(progUpscale)
        GLES20.glUniform1i(loc(progUpscale, "uTex"), 0)
        GLES20.glUniformMatrix4fv(loc(progUpscale, "uTexMat"), 1, false, texMat, 0)
        GLES20.glUniform2f(loc(progUpscale, "uSrcSize"), srcW.toFloat(), srcH.toFloat())
        GLES20.glUniform1f(loc(progUpscale, "uSharp"), if (upscaleHeight > 0) 0.6f else 0.0f)
        drawQuad()

        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, smallFbo[slot])
        GLES20.glViewport(0, 0, workW, workH)
        GLES20.glUseProgram(progLuma)
        GLES20.glUniform1i(loc(progLuma, "uTex"), 0)
        GLES20.glUniformMatrix4fv(loc(progLuma, "uTexMat"), 1, false, texMat, 0)
        GLES20.glUniform2f(loc(progLuma, "uSrcSize"), srcW.toFloat(), srcH.toFloat())
        drawQuad()
    }

    private fun runMotionEstimation() {
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, mvFbo)
        GLES20.glViewport(0, 0, mvW, mvH)
        GLES20.glUseProgram(progMe)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, smallTex[cur])
        GLES20.glActiveTexture(GLES20.GL_TEXTURE1)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, smallTex[1 - cur])
        GLES20.glUniform1i(loc(progMe, "uCur"), 0)
        GLES20.glUniform1i(loc(progMe, "uPrev"), 1)
        GLES20.glUniform2i(loc(progMe, "uWorkSize"), workW, workH)
        drawQuad()
    }

    // ------------------------------------------------------------------ per vsync

    private fun draw() {
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
        GLES20.glViewport(0, 0, surfW, surfH)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        if (!haveFrame) return

        val va = srcW * pixelRatio / srcH
        var w = surfW
        var h = (w / va).toInt()
        if (h > surfH) {
            h = surfH
            w = (h * va).toInt()
        }
        GLES20.glViewport((surfW - w) / 2, (surfH - h) / 2, max(1, w), max(1, h))

        val useMv = mvReady && interpolate
        val t = if (useMv) {
            ((System.nanoTime() - lastFrameNs) / intervalNs).toFloat().coerceIn(0f, 1f)
        } else 1f

        GLES20.glUseProgram(progShow)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, bigTex[1 - cur])
        GLES20.glActiveTexture(GLES20.GL_TEXTURE1)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, bigTex[cur])
        GLES20.glActiveTexture(GLES20.GL_TEXTURE2)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, mvTex)
        GLES20.glUniform1i(loc(progShow, "uA"), 0)
        GLES20.glUniform1i(loc(progShow, "uB"), 1)
        GLES20.glUniform1i(loc(progShow, "uMv"), 2)
        GLES20.glUniform1f(loc(progShow, "uT"), t)
        GLES20.glUniform1f(loc(progShow, "uUseMv"), if (useMv) 1f else 0f)
        GLES20.glUniform2f(loc(progShow, "uWorkSize"), workW.toFloat(), workH.toFloat())
        drawQuad()
    }

    // ------------------------------------------------------------------ helpers

    private fun drawQuad() = GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

    private fun loc(p: Int, n: String) = GLES20.glGetUniformLocation(p, n)

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(s)
            GLES20.glDeleteShader(s)
            throw RuntimeException("Shader error: $log")
        }
        return s
    }

    private fun program(vs: String, fs: String): Int {
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("Link error: " + GLES20.glGetProgramInfoLog(p))
        return p
    }

    companion object {
        private const val VS = """#version 300 es
layout(location = 0) in vec2 aPos;
out vec2 vUv;
void main() {
    vUv = aPos * 0.5 + 0.5;
    gl_Position = vec4(aPos, 0.0, 1.0);
}
"""

        // Upscaler: bicubic Catmull-Rom (9 tap) + unsharp mask dengan batas min/max lokal (anti ringing)
        private const val FS_UPSCALE = """#version 300 es
#extension GL_OES_EGL_image_external_essl3 : require
precision highp float;
uniform samplerExternalOES uTex;
uniform mat4 uTexMat;
uniform vec2 uSrcSize;
uniform float uSharp;
in vec2 vUv;
out vec4 o;

vec3 fetch(vec2 p) { return texture(uTex, p).rgb; }

void main() {
    vec2 uv = (uTexMat * vec4(vUv, 0.0, 1.0)).xy;
    vec2 sp = uv * uSrcSize;
    vec2 t1 = floor(sp - 0.5) + 0.5;
    vec2 f = sp - t1;
    vec2 w0 = f * (-0.5 + f * (1.0 - 0.5 * f));
    vec2 w1 = 1.0 + f * f * (-2.5 + 1.5 * f);
    vec2 w2 = f * (0.5 + f * (2.0 - 1.5 * f));
    vec2 w3 = f * f * (-0.5 + 0.5 * f);
    vec2 w12 = w1 + w2;
    vec2 o12 = w2 / w12;
    vec2 p0 = (t1 - 1.0) / uSrcSize;
    vec2 p3 = (t1 + 2.0) / uSrcSize;
    vec2 p12 = (t1 + o12) / uSrcSize;

    vec3 bic = vec3(0.0);
    bic += fetch(vec2(p0.x,  p0.y))  * w0.x  * w0.y;
    bic += fetch(vec2(p12.x, p0.y))  * w12.x * w0.y;
    bic += fetch(vec2(p3.x,  p0.y))  * w3.x  * w0.y;
    bic += fetch(vec2(p0.x,  p12.y)) * w0.x  * w12.y;
    bic += fetch(vec2(p12.x, p12.y)) * w12.x * w12.y;
    bic += fetch(vec2(p3.x,  p12.y)) * w3.x  * w12.y;
    bic += fetch(vec2(p0.x,  p3.y))  * w0.x  * w3.y;
    bic += fetch(vec2(p12.x, p3.y))  * w12.x * w3.y;
    bic += fetch(vec2(p3.x,  p3.y))  * w3.x  * w3.y;

    if (uSharp <= 0.0) { o = vec4(clamp(bic, 0.0, 1.0), 1.0); return; }

    vec2 px = 1.0 / uSrcSize;
    vec3 c  = fetch(uv);
    vec3 n1 = fetch(uv + vec2(px.x, 0.0));
    vec3 n2 = fetch(uv - vec2(px.x, 0.0));
    vec3 n3 = fetch(uv + vec2(0.0, px.y));
    vec3 n4 = fetch(uv - vec2(0.0, px.y));
    vec3 blur = (n1 + n2 + n3 + n4) * 0.25;
    vec3 mn = min(min(min(n1, n2), min(n3, n4)), c);
    vec3 mx = max(max(max(n1, n2), max(n3, n4)), c);
    vec3 r = bic + uSharp * (c - blur);
    r = clamp(r, mn, mx);
    o = vec4(clamp(r, 0.0, 1.0), 1.0);
}
"""

        // Versi kecil (1/4) dalam luma untuk estimasi gerak
        private const val FS_LUMA = """#version 300 es
#extension GL_OES_EGL_image_external_essl3 : require
precision highp float;
uniform samplerExternalOES uTex;
uniform mat4 uTexMat;
uniform vec2 uSrcSize;
in vec2 vUv;
out vec4 o;
void main() {
    vec2 uv = (uTexMat * vec4(vUv, 0.0, 1.0)).xy;
    vec2 st = 1.0 / uSrcSize;
    vec3 c = texture(uTex, uv + vec2(-st.x, -st.y)).rgb
           + texture(uTex, uv + vec2( st.x, -st.y)).rgb
           + texture(uTex, uv + vec2(-st.x,  st.y)).rgb
           + texture(uTex, uv + vec2( st.x,  st.y)).rgb;
    c *= 0.25;
    float l = dot(c, vec3(0.299, 0.587, 0.114));
    o = vec4(l, l, l, 1.0);
}
"""

        // Block matching 4x4 (resolusi kecil): coarse step 2 pada +-8, lalu refine +-1.
        // Hasil: rg = vektor (d/10*0.5+0.5), b = SAD ter-normalisasi.
        // Arti vektor d: B(x) ~= A(x + d)
        private const val FS_ME = """#version 300 es
precision highp float;
precision highp int;
uniform sampler2D uCur;
uniform sampler2D uPrev;
uniform ivec2 uWorkSize;
out vec4 o;

float blockCost(ivec2 base, ivec2 d) {
    float s = 0.0;
    for (int y = 0; y < 4; y++) {
        for (int x = 0; x < 4; x++) {
            ivec2 p = base + ivec2(x, y);
            ivec2 q = clamp(p + d, ivec2(0), uWorkSize - 1);
            s += abs(texelFetch(uCur, p, 0).r - texelFetch(uPrev, q, 0).r);
        }
    }
    return s / 16.0;
}

void main() {
    ivec2 base = ivec2(gl_FragCoord.xy) * 4;
    ivec2 best = ivec2(0);
    float bestSad = blockCost(base, best);
    float bestCost = bestSad;

    for (int dy = -8; dy <= 8; dy += 2) {
        for (int dx = -8; dx <= 8; dx += 2) {
            ivec2 d = ivec2(dx, dy);
            float c = blockCost(base, d);
            float cost = c + 0.004 * length(vec2(d));
            if (cost < bestCost) { bestCost = cost; best = d; bestSad = c; }
        }
    }
    ivec2 center = best;
    for (int dy = -1; dy <= 1; dy++) {
        for (int dx = -1; dx <= 1; dx++) {
            ivec2 d = center + ivec2(dx, dy);
            float c = blockCost(base, d);
            float cost = c + 0.004 * length(vec2(d));
            if (cost < bestCost) { bestCost = cost; best = d; bestSad = c; }
        }
    }
    vec2 enc = vec2(best) / 10.0 * 0.5 + 0.5;
    o = vec4(enc, clamp(bestSad * 5.0, 0.0, 1.0), 1.0);
}
"""

        // Frame perantara motion-compensated; fallback ke "hold" bila gerak tidak bisa dipercaya
        // (scene cut / oklusi) supaya tidak ada ghosting.
        private const val FS_SHOW = """#version 300 es
precision highp float;
uniform sampler2D uA;
uniform sampler2D uB;
uniform sampler2D uMv;
uniform float uT;
uniform float uUseMv;
uniform vec2 uWorkSize;
in vec2 vUv;
out vec4 o;
void main() {
    vec3 b0 = texture(uB, vUv).rgb;
    if (uUseMv < 0.5) { o = vec4(b0, 1.0); return; }
    vec4 e = texture(uMv, vUv);
    vec2 d = (e.rg * 2.0 - 1.0) * 10.0;
    vec2 duv = d / uWorkSize;
    vec3 a = texture(uA, vUv + uT * duv).rgb;
    vec3 b = texture(uB, vUv - (1.0 - uT) * duv).rgb;
    vec3 mc = mix(a, b, uT);
    vec3 hold = (uT < 0.5) ? texture(uA, vUv).rgb : b0;
    float conf = 1.0 - smoothstep(0.35, 0.8, e.b);
    float agree = 1.0 - smoothstep(0.12, 0.35, length(a - b));
    o = vec4(mix(hold, mc, conf * agree), 1.0);
}
"""
    }
}
